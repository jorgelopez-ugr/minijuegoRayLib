/*
Jorge López Molina
DNI: 78114273V
Marino Fernández Pérez
DNI: 75941131F
1ºA grupo 2
*/

#ifndef _PUNTO2D_
#define _PUNTO2D_

#include <iostream>
#include <string>

using namespace std;

const int MIN_DIM = 750;
const float UMBRAL = 0.1;

class Punto2D {
private:
    float x, y;
    void AjustarPosicion(int ancho, int alto); 
    
public:
    Punto2D();

    Punto2D(float _x, float _y) : x(_x), y(_y){
    };

    float getX() const;
    
    float getY() const;
    
    void setXY(float, float);

    float distancia(const Punto2D & otro) const; 

    bool colision(const Punto2D & otro) const; 

    void mover(float dx, float dy);

    void rotar(const Punto2D & pivot, float rads);

    std::string toString() const;

    void moverHacia(const Punto2D & destino, float speed);
    
    friend ostream& operator<<(ostream &flujo, const Punto2D &punto);
    
    friend istream& operator>>(istream &flujo, Punto2D &punto);
    
    bool operator==(const Punto2D & otro);
};

#endif
