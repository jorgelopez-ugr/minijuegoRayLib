/*
Jorge López Molina
DNI: 78114273V
Marino Fernández Pérez
DNI: 75941131F
1ºA grupo 2
*/

#ifndef ASTEROIDE_H
#define ASTEROIDE_H

#include "PoliReg.h"
#include "Punto2D.h"
#include <iostream>
#include <cmath>
#include <string>

using namespace std;

class Asteroide{
private:
    PoliReg roca;
    Punto2D veloc;
    float giro;
    
public:
    Asteroide();
    
    Asteroide(const PoliReg & pol);
    
    Asteroide(const PoliReg & pol,const Punto2D & vel,float rads);
    
    Asteroide(const Asteroide & otro);
    
    void setGiro(float rads){
        giro = rads;
    }
    
    void setVeloc(const Punto2D & trayectoria){
       veloc = trayectoria; 
    }
    
    void setPosicion(const Punto2D & nuevo){
    	roca.setCentro(nuevo);
    }
    
    Punto2D getVeloc() const{
        return veloc;
    }
    
    float getGiro() const{
        return giro;
    }
    
    PoliReg getRoca() const{
        return roca;
    }
    
    void setRoca(const PoliReg & otra){
    	roca = otra;
    }
    
    void eliminaVertice();
    
    Punto2D getPosicion() const{
        return roca.getCentro(); 
    }
    
    void mover(bool direccion);
    
    void rotar();
    
    bool colisiona(const Asteroide & otro) const;
    
    Asteroide& operator=(Asteroide & rhs);
};

#endif
