/*
Jorge López Molina
DNI: 78114273V
Marino Fernández Pérez
DNI: 75941131F
1ºA grupo 2
*/

#include "PoliReg.h"
#include "Punto2D.h"
#include "Asteroide.h"
#include <iostream>

using namespace std;

Asteroide::Asteroide() : roca(random() % 8, Punto2D(), random() % 60){
    veloc.setXY(2,2);  
    giro = 0.1; 
}
    
Asteroide::Asteroide(const PoliReg & pol){
    veloc.setXY(2,2);
    roca = pol;
    giro = 0;
}

Asteroide::Asteroide(const PoliReg & pol, const Punto2D & vel, float rads) : roca(pol), veloc(vel), giro(rads){ 
}

Asteroide::Asteroide(const Asteroide & otro){
    giro = otro.getGiro();
    veloc = otro.getVeloc();
    roca =otro.getRoca();
}

void Asteroide::eliminaVertice(){
    roca.eliminaVertice();
}

void Asteroide::mover(bool direccion){
    if (direccion){
        roca.mover(veloc.getX(),veloc.getY());
    }
    else{
        roca.mover(-veloc.getX(),-veloc.getY());
    }
}

void Asteroide::rotar(){
    roca.rotar(giro);
}

bool Asteroide::colisiona(const Asteroide & otro) const{
    return (roca.colision(otro.getRoca()));
}

Asteroide& Asteroide::operator=(Asteroide & rhs){
    if (this != &rhs){
        roca = rhs.getRoca(); 
        giro = rhs.getGiro();
        veloc = rhs.getVeloc(); 
    }
    
    return (*this);
}
