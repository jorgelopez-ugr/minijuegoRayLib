/*
Jorge López Molina
DNI: 78114273V
Marino Fernández Pérez
DNI: 75941131F
1ºA grupo 2
*/

#include "raylib.h"
#include "Asteroide.h"
#include "PoliReg.h"
#include "Punto2D.h"
#include "ConjuntoAsteroides.h"

#include <string>
#include <cmath>

const int screenWidth = 1200;
const int screenHeight = 800;

using namespace std;

void pintaPunto(const Punto2D & p, Color c) {
    DrawCircle(p.getX(), p.getY(), 7.0, c);
}

void pintaLinea(const Punto2D & p1, const Punto2D & p2, Color c){
    DrawLine(p1.getX(), p1.getY(), p2.getX(), p2.getY(), c);
} 

void pintaPoligono(const PoliReg & poligono1, Color c){
    for (int i = 1 ; i < poligono1.getLados() ; i++){
     
        pintaLinea(poligono1.getVertice(i), poligono1.getVertice(i-1), c);
    }
    
    pintaLinea(poligono1.getVertice(poligono1.getLados()-1), poligono1.getVertice(0), c);

}

void pintaAsteroide(Asteroide & asteroide1, Color c){
    pintaPoligono(asteroide1.getRoca(), c);
}

void pintaConjunto(ConjuntoAsteroides & uno, Color c){
    for (int i = 0 ; i < uno.getUtil() ; i++){
        Asteroide current(uno.getElemento(i));
        
        pintaAsteroide(current, c);
    }
}

bool colisionDcha(const Asteroide & uno){
    return (uno.getPosicion().getX() + uno.getRoca().getRadio() >= screenWidth);
}

bool colisionIzda(const Asteroide & uno){
    return (uno.getPosicion().getX() - uno.getRoca().getRadio() <= 0);
}

bool colisionArrib(const Asteroide & uno){
    return (uno.getPosicion().getY() - uno.getRoca().getRadio() <= 0);
}

bool colisionAbaj(const Asteroide & uno){
    return (uno.getPosicion().getY() + uno.getRoca().getRadio() >= screenHeight);
}

void moverAsteroide(Asteroide & nave,bool direccion){
    if (!colisionDcha(nave)){
        nave.mover(direccion);
    }
    
    if (!colisionIzda(nave)){
        nave.mover(direccion);
    }
}

void intercambiaVeloc(Asteroide &uno, Asteroide &otro){
    Punto2D aux(uno.getVeloc());

    uno.setVeloc(otro.getVeloc());
    otro.setVeloc(aux);
}

//MAIN

int main(void){
    InitWindow(screenWidth, screenHeight, "Modulo de prueba");
   
    //SELECTOR DE DIFICULTAD
    
    int dificultad = 0;
    bool jugar = false;
   
    while (!WindowShouldClose() && !jugar){
    	BeginDrawing();

    	ClearBackground(BLACK);
                
        DrawText("Seleccione una dificulad", screenWidth / 2 - 250, screenHeight / 2 - 100, 50, RED);
        DrawText("F - facil", screenWidth / 2 - 250, screenHeight / 2 - 50, 50, RED);
        DrawText("M - media", screenWidth / 2 - 250, screenHeight / 2, 50, RED);
        DrawText("D - dificil", screenWidth / 2 - 250, screenHeight / 2 + 50, 50, RED);
    	EndDrawing();

        //SELECCION MEDIANTE TECLAS
        
    	if (IsKeyPressed(KEY_F)){
            dificultad = 7;
	}
        
        if (IsKeyPressed(KEY_M)){
            dificultad = 9;
	}
        
        if (IsKeyPressed(KEY_D)){
            dificultad = 12;
	}
        
        if (dificultad != 0){
            jugar = true;
        }
    }
    
    SetTargetFPS(40);
    
    //DECLARACION DE CONSTANTES Y CONJUNTOS
    
    const int MAX_DISP_GEN = 5;
    const int MAX_AST_GEN = 60;
    const int TAMANIO_NAVE = 25;
    
    ConjuntoAsteroides asteroides;
    ConjuntoAsteroides disparos;
        
    //DECLARACION DE PARAMETROS :: nave
   
    Punto2D centro_nave(screenWidth / 2, screenHeight - 50);
    PoliReg forma_nave(8, centro_nave, TAMANIO_NAVE);
    Punto2D vel_nave(5, 0);
    
    Asteroide nave(forma_nave, vel_nave, 2);
    
    //DECLARACION DE PARAMETROS :: sistema de vidas y puntuación
    
    int nro_vidas = 3;
    int ptos = 0;

    bool game_over = false;
    bool winner = false;
    
    int generados = 0;
    int eliminados = 0;
   
    //JUEGO
    
    while (!WindowShouldClose() && !game_over){
        
        //GENERACION CONSTANTE DE ASTEROIDES SEGUN LA DIF. ESCOGIDA
        
        if (generados < MAX_AST_GEN && asteroides.getUtil() < (rand() % dificultad)){
            const int MAX_AST_FRAME = 1;

            for (int i = 0 ; i < MAX_AST_FRAME; i++){    
                if (generados < MAX_AST_GEN){
                    Punto2D pos_aleatoria;
                    asteroides.aniade(pos_aleatoria, true); //TRUE ASTEROIDE FALSE DISPARO
                    generados++;
                }
            }
        }
      	
        //PARTE DE DETECCION DE TECLAS + MOVIMIENTOS
        
        if (IsKeyDown(KEY_LEFT) && !colisionIzda(nave)){
            moverAsteroide(nave, false);
        }
        
        if (IsKeyDown(KEY_RIGHT) && !colisionDcha(nave)){
            moverAsteroide(nave, true);
        }
        
        if (IsKeyPressed(KEY_UP) && disparos.getUtil() <= MAX_DISP_GEN){
            disparos.aniade(nave.getPosicion(), false);
        }
        

        //COLISIONES
        
        for (int i = 0 ; i < asteroides.getUtil() ; i++){
            asteroides.getElemento(i).mover(true);
            
            //ASTEROIDES
            
            for (int j = 0 ; j < asteroides.getUtil() ; j++){
                if (asteroides.getElemento(i).colisiona(asteroides.getElemento(j)))
                    intercambiaVeloc(asteroides.getElemento(i), asteroides.getElemento(j));
            }
            
            asteroides.getElemento(i).rotar();
            
            //DISPAROS Y PUNTUACIONES
            
            for (int j = 0 ; j < disparos.getUtil() ; j++){
                    int util_anterior = asteroides.getUtil();
                    
                    if (asteroides.getElemento(i).colisiona(disparos.getElemento(j))){
                        asteroides.eliminaLado(i);
                        ptos += 20;
                        
                        if (asteroides.getUtil() < util_anterior){
                            eliminados++;
                            ptos += 80;
                        }
                        
                        disparos.eliminaLado(j);
                    }
            }
            
            disparos.getElemento(i).mover(true);
            asteroides.getElemento(i).rotar();
            
            //LIMITES - ASTEROIDES
            
            //somos conscientes de que parece mucho codigo repetido pero es necesario
            //para lograr un rebote minimamente realista con las paredes
            
            if (colisionDcha(asteroides.getElemento(i))){
                Punto2D nueva(-asteroides.getElemento(i).getVeloc().getX(), asteroides.getElemento(i).getVeloc().getY());
                asteroides.getElemento(i).setVeloc(nueva);
            }
            
            if (colisionIzda(asteroides.getElemento(i))){
                Punto2D nueva(-asteroides.getElemento(i).getVeloc().getX(), asteroides.getElemento(i).getVeloc().getY());
                asteroides.getElemento(i).setVeloc(nueva);
            }
            
            if (colisionArrib(asteroides.getElemento(i))){
                Punto2D nueva(asteroides.getElemento(i).getVeloc().getX(), -asteroides.getElemento(i).getVeloc().getY());
                asteroides.getElemento(i).setVeloc(nueva);
            }
            
            if (colisionAbaj(asteroides.getElemento(i))){
                Punto2D nueva(asteroides.getElemento(i).getVeloc().getX(), -asteroides.getElemento(i).getVeloc().getY());
                asteroides.getElemento(i).setVeloc(nueva);
            }
            
            //LIMITES - DISPAROS
            
            if (colisionArrib(disparos.getElemento(0))){
                disparos.eliminaLado(0);
            }
            
            // SISTEMA DE VIDAS Y PUNTUACIONES
            
            if (asteroides.getElemento(i).colisiona(nave)){
              	nro_vidas--;
                ptos -= 100; 
                
                nave.setPosicion(centro_nave);  //POSICION DEFAULT TRAS PERDER VIDA
                
                if (nro_vidas == 0){
                    game_over = true;
                }
            }
        }
       
        //GANADOR
        
        if (eliminados >= 20){
            winner = true;
            DrawText("Has ganado!", screenWidth / 2 - 70, screenHeight / 2 - 10, 30, GREEN);
            
            EndDrawing();
            continue;
        }

        
        //APARTADO GRAFICO
        
        BeginDrawing();
            
        ClearBackground(BLACK);

        pintaConjunto(asteroides,RED);
        pintaConjunto(disparos,LIME);
        pintaAsteroide(nave, BLUE);

        string a = "nro de asteroides eliminados: " + to_string(eliminados);
        string s = "puntuacion: " + to_string(ptos);
        string p = "vidas restantes: " + to_string(nro_vidas);

        DrawText(a.c_str(), 775, 60, 25, BLUE);
        DrawText(p.c_str(), 927, 40, 25, BLUE);
        DrawText(s.c_str(), 995, 80, 25, BLUE);
        DrawText("ESC para salir", 10, 50, 15, BLUE);
   
        EndDrawing();
    }
    
    CloseWindow();
        
    return 0; 
}
