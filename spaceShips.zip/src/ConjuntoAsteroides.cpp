/*
Jorge López Molina
DNI: 78114273V
Marino Fernández Pérez
DNI: 75941131F
1ºA grupo 2
*/

#include "PoliReg.h"
#include "Punto2D.h"
#include "Asteroide.h"
#include "ConjuntoAsteroides.h"
#include <iostream>

using namespace std;

void ConjuntoAsteroides::_borrado(int ind){
    if (ind == util-1){
        contrae();
    }
    else{
        for (int i = ind ; i < util ; i++){
            conjunto[i] = conjunto[i+1];
        }
        contrae();
    }
}

ConjuntoAsteroides::ConjuntoAsteroides(){
    util = 0;
}

void ConjuntoAsteroides::aniade(const Punto2D & posicion , bool ast_o_disp){ //TRUE ASTEROIDE FALSE DISPARO
	if (ast_o_disp){
	    if ((util + 1) <= 40){
    	        Asteroide nuevo;
                nuevo.setPosicion(posicion);
   	
    	        conjunto[util] = nuevo;
    	        util++;
	    }
	}
	else{
	    if ((util + 1) <= 40){
    		PoliReg triangulo;
    	        Asteroide nuevo(triangulo);
   	
   	        nuevo.setPosicion(posicion);
   	        
   	        Punto2D trayectoria(0, -10);
   	   	nuevo.setVeloc(trayectoria);
   	
    	        conjunto[util] = nuevo;
    	        util++;
    	    }
	}
}

void ConjuntoAsteroides::contrae(){
    if (util > 0){
        util--;
    }
}

void ConjuntoAsteroides::eliminaLado(int ind){
    int nro_lados = conjunto[ind].getRoca().getLados();
    
    if (nro_lados == PoliReg::MIN_PTOS){ 
        _borrado(ind);
    }
    else{
        conjunto[ind].eliminaVertice();
    }
}

ConjuntoAsteroides &ConjuntoAsteroides::operator=(ConjuntoAsteroides & otro){ 
    
    util = otro.getUtil();
    
    for (int i = 0 ; i < util ; i++){
        conjunto[i] = otro.getElemento(i);
    }
    
    return (*this);
}
